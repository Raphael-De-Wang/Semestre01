import sys

def main():
    arr = sys.argv
    print(int(arr[1]) + int(arr[2]))

if __name__ == "__main__":
    main()
