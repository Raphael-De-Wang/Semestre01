import numpy as np
import matplotlib.pyplot as plt

a = 2
m0 = np.array([[1,2],[3,4]])
